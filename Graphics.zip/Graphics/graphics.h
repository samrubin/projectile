#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <QMainWindow>
#include <qcustomplot.h>
#include<QDoubleSpinBox>

namespace Ui {
class graphics;
}

class graphics : public QMainWindow
{
    Q_OBJECT



public:
    explicit graphics(QWidget *parent = 0);

     double initialVelocity;
    double angle;
    char angleType;
void graph(QCustomPlot *customPlot);
~graphics();
private slots:
    void on_velocity_valueChanged(double arg1);

    void on_angle_valueChanged(double arg1);

    void on_Degree_toggled(bool checked);

    void on_Radian_toggled(bool checked);



private:
    Ui::graphics *ui;
   // QDoubleSpinBox* initialVelocity;
};

#endif // GRAPHICS_H
