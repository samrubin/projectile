#include "graphics.h"
#include "ui_graphics.h"
#include "qcustomplot.h"

graphics::graphics(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::graphics)
{
    ui->setupUi(this);
}

graphics::~graphics()
{
    delete ui;
}

void graphics::on_velocity_valueChanged(double arg1)
{
    initialVelocity = arg1;
}

void graphics::on_angle_valueChanged(double arg1)
{

    angle = arg1;
}

void graphics::on_Degree_toggled(bool checked)
{
    if (checked){
        angleType = 'd';
    }
}

void graphics::on_Radian_toggled(bool checked)
{
    if (checked){
        angleType = 'r';
    }
}
