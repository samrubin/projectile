#include "graphics.h"
#include <QApplication>
void graph();
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    graphics w;
    w.show();
 //   graph();

    return a.exec();
}
