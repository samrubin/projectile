#include "graphics.h"
#include "qcustomplot.h"
#include <cmath>

void graphics::graph(QCustomPlot *customPlot){
/*  double initialVelocityX;
    double initialVelocityY;
    //double angle = graphics::angle;
    //double initialVelocity = graphics::initialVelocity;
    //char angleType = graphics::angleType;

    const double G = 9.8;
//    const double M_PI = 3.14159265;

if (angleType == 'd') {
    angle = angle * M_PI / 180;
    initialVelocityX = initialVelocity * cos(angle);
    initialVelocityY = initialVelocity * sin(angle);
}
else if (angleType == 'r') {
    initialVelocityX = initialVelocity * cos(angle);
    initialVelocityY = initialVelocity * sin(angle);
}







double a[101];
double b[101];
//double heightMax = (initialVelocityY * initialVelocityY) / (2 * G);

double time1 = (-initialVelocityY + sqrt(initialVelocityY * initialVelocityY - 4 * (0)) / (-G));
double time2 = (-initialVelocityY - sqrt(initialVelocityY * initialVelocityY - 4 * (0)) / (-G));
if (time1 > time2){
}else if (time2 > time1){
}else
    return;
double rangeMax = initialVelocityX * time1;
double rangeMin = initialVelocityY * time2;
double rangeTot = (rangeMax-rangeMin);

for (int k = 0; k < 101; k++){
    a[k] = k/ (rangeTot + rangeMin);
    b[k] = 0.5 * (-G) * (a[k] / initialVelocityX) * (a[k] / initialVelocityX) + initialVelocityY * (a[k] / initialVelocityX);
}*/
/*QVector<double> x(101), y(101);
for (int k = 0; k < 101;k++){
    x[k] = a[k];
    y[k] = b[k];
}
//QCustomPlot *customPlot = (ui->widget);
customPlot->addGraph();
customPlot->graph(0)->setData(x, y);
// give the axes some labels:
customPlot->xAxis->setLabel("Horizontal Distance (m)");
customPlot->yAxis->setLabel("Vertical Distance (m)");
// set axes ranges, so we see all data:
customPlot->xAxis->setRange(rangeMin, rangeMax);
customPlot->yAxis->setRange(0, heightMax);
customPlot->replot();


// create graph and assign data to it:
customPlot->addGraph();
customPlot->graph(0)->setData(x, y);
// give the axes some labels:
customPlot->xAxis->setLabel("x");
customPlot->yAxis->setLabel("y");
// set axes ranges, so we see all data:
customPlot->xAxis->setRange(-1, 1);
customPlot->yAxis->setRange(0, 1);
customPlot->replot();
*/

QVector<double> x(101), y(101); // initialize with entries 0..100
for (int i=0; i<101; ++i)
{
  x[i] = i/50.0 - 1; // x goes from -1 to 1
  y[i] = x[i]*x[i]; // let's plot a quadratic function
}
// create graph and assign data to it:
customPlot->addGraph();
customPlot->graph(0)->setData(x, y);
// give the axes some labels:
customPlot->xAxis->setLabel("x");
customPlot->yAxis->setLabel("y");
// set axes ranges, so we see all data:
customPlot->xAxis->setRange(-1, 1);
customPlot->yAxis->setRange(0, 1);
customPlot->replot();
}

